/**
 * Emma Vault Extension - Popup Controller
 * Self-contained vault management interface
 * Built with love for Debbe and all precious memories
 */

// Application State
class EmmaVaultExtension {
  constructor() {
    this.currentVault = null;
    this.vaultData = null;
    this.isVaultOpen = false;
    this.recentVaults = [];
    
    // DOM Elements
    this.elements = {
      // States
      welcomeState: document.getElementById('welcomeState'),
      activeVaultState: document.getElementById('activeVaultState'),
      
      // Welcome state elements
      vaultDropZone: document.getElementById('vaultDropZone'),
      createNewVault: document.getElementById('createNewVault'),
      openExistingVault: document.getElementById('openExistingVault'),
      recentVaults: document.getElementById('recentVaults'),
      noRecentVaults: document.getElementById('noRecentVaults'),
      
      // Active vault elements
      activeVaultName: document.getElementById('activeVaultName'),
      activeVaultPath: document.getElementById('activeVaultPath'),
      vaultStatusIndicator: document.getElementById('vaultStatusIndicator'),
      memoryCount: document.getElementById('memoryCount'),
      vaultSize: document.getElementById('vaultSize'),
      lastSyncTime: document.getElementById('lastSyncTime'),
      
      // Action buttons
      addMemoryBtn: document.getElementById('addMemoryBtn'),
      openWebAppBtn: document.getElementById('openWebAppBtn'),
      downloadVaultBtn: document.getElementById('downloadVaultBtn'),
      closeVaultBtn: document.getElementById('closeVaultBtn'),
      
      // Modal
      modalOverlay: document.getElementById('modalOverlay'),
      modalContent: document.getElementById('modalContent'),
      
      // Version
      version: document.getElementById('version')
    };
    
    console.log('💜 Emma Vault Extension initialized');
  }
  
  async init() {
    console.log('🚀 Initializing Emma Vault Extension...');
    
    // Set version
    const manifest = chrome.runtime.getManifest();
    this.elements.version.textContent = manifest.version;
    
    // Load saved state
    await this.loadState();
    
    // Set up event listeners
    this.setupEventListeners();
    
    // Update UI
    this.updateUI();
    
    console.log('✅ Emma Vault Extension ready');
  }
  
  async loadState() {
    try {
      const storage = await chrome.storage.local.get([
        'currentVault',
        'recentVaults',
        'vaultData'
      ]);
      
      this.currentVault = storage.currentVault || null;
      this.recentVaults = storage.recentVaults || [];
      this.vaultData = storage.vaultData || null;
      this.isVaultOpen = !!(this.currentVault && this.vaultData);
      
      console.log('📊 State loaded:', {
        hasVault: !!this.currentVault,
        recentCount: this.recentVaults.length
      });
      
    } catch (error) {
      console.error('❌ Error loading state:', error);
    }
  }
  
  async saveState() {
    try {
      await chrome.storage.local.set({
        currentVault: this.currentVault,
        recentVaults: this.recentVaults,
        vaultData: this.vaultData
      });
      
      console.log('💾 State saved');
    } catch (error) {
      console.error('❌ Error saving state:', error);
    }
  }
  
  setupEventListeners() {
    // Welcome state actions
    this.elements.vaultDropZone.addEventListener('click', () => this.openExistingVault());
    this.elements.createNewVault.addEventListener('click', () => this.createNewVault());
    this.elements.openExistingVault.addEventListener('click', () => this.openExistingVault());
    
    // Active vault actions
    this.elements.addMemoryBtn.addEventListener('click', () => this.addMemory());
    this.elements.openWebAppBtn.addEventListener('click', () => this.openWebApp());
    this.elements.downloadVaultBtn.addEventListener('click', () => this.downloadVault());
    this.elements.closeVaultBtn.addEventListener('click', () => this.closeVault());
    
    // Modal close
    this.elements.modalOverlay.addEventListener('click', (e) => {
      if (e.target === this.elements.modalOverlay) {
        this.closeModal();
      }
    });
    
    console.log('🎧 Event listeners set up');
  }
  
  updateUI() {
    if (this.isVaultOpen) {
      this.showActiveVaultState();
    } else {
      this.showWelcomeState();
    }
    
    this.updateRecentVaults();
  }
  
  showWelcomeState() {
    this.elements.welcomeState.classList.remove('hidden');
    this.elements.activeVaultState.classList.add('hidden');
    console.log('📋 Showing welcome state');
  }
  
  showActiveVaultState() {
    this.elements.welcomeState.classList.add('hidden');
    this.elements.activeVaultState.classList.remove('hidden');
    
    // Update vault info
    if (this.currentVault) {
      this.elements.activeVaultName.textContent = this.vaultData?.name || 'My Memories';
      this.elements.activeVaultPath.textContent = this.currentVault.fileName || 'vault.emma';
      
      // Update stats
      const memoryCount = Object.keys(this.vaultData?.content?.memories || {}).length;
      this.elements.memoryCount.textContent = memoryCount;
      
      const vaultSize = this.calculateVaultSize();
      this.elements.vaultSize.textContent = this.formatBytes(vaultSize);
      
      // Update sync time
      const lastSync = this.currentVault.lastSync;
      if (lastSync) {
        this.elements.lastSyncTime.textContent = this.formatTimeAgo(new Date(lastSync));
      } else {
        this.elements.lastSyncTime.textContent = 'Never';
      }
      
      // Update status indicator
      this.elements.vaultStatusIndicator.textContent = '🟢';
    }
    
    console.log('📁 Showing active vault state');
  }
  
  updateRecentVaults() {
    const container = this.elements.recentVaults;
    const noRecent = this.elements.noRecentVaults;
    
    // Clear existing items (except template and no-recent message)
    const existingItems = container.querySelectorAll('.recent-vault-item:not(#recentVaultTemplate)');
    existingItems.forEach(item => item.remove());
    
    if (this.recentVaults.length === 0) {
      noRecent.style.display = 'block';
      return;
    }
    
    noRecent.style.display = 'none';
    
    // Add recent vault items
    this.recentVaults.slice(0, 3).forEach(vault => {
      const item = this.createRecentVaultItem(vault);
      container.appendChild(item);
    });
  }
  
  createRecentVaultItem(vault) {
    const template = document.getElementById('recentVaultTemplate');
    const item = template.cloneNode(true);
    item.id = '';
    item.style.display = 'flex';
    
    const nameEl = item.querySelector('.vault-name');
    const detailsEl = item.querySelector('.vault-details');
    
    nameEl.textContent = vault.name || 'Unnamed Vault';
    detailsEl.textContent = `Last opened: ${this.formatTimeAgo(new Date(vault.lastOpened))}`;
    
    item.addEventListener('click', () => this.openRecentVault(vault));
    
    return item;
  }
  
  async createNewVault() {
    console.log('🌟 Creating new vault...');
    
    try {
      // Show vault creation modal
      await this.showVaultCreationModal();
      
    } catch (error) {
      if (error.name === 'AbortError') {
        console.log('User cancelled vault creation');
        return;
      }
      console.error('❌ Vault creation failed:', error);
      this.showError('Failed to create vault: ' + error.message);
    }
  }
  
  async openExistingVault() {
    console.log('📁 Opening existing vault...');
    
    try {
      // Check if File System Access API is supported
      if (!window.showOpenFilePicker) {
        this.showError('File System Access API not supported. Please use Chrome or Edge.');
        return;
      }
      
      // Show file picker
      const [fileHandle] = await window.showOpenFilePicker({
        types: [
          {
            description: 'Emma Vault Files',
            accept: {
              'application/emma': ['.emma'],
              'application/json': ['.emma']
            }
          }
        ]
      });
      
      // Read and parse vault file
      const file = await fileHandle.getFile();
      const content = await file.text();
      const vaultData = JSON.parse(content);
      
      // Validate vault structure
      if (!this.validateVaultData(vaultData)) {
        throw new Error('Invalid vault file format');
      }
      
      // Set up vault
      this.currentVault = {
        fileHandle: fileHandle,
        fileName: fileHandle.name,
        lastSync: new Date().toISOString(),
        lastOpened: new Date().toISOString()
      };
      
      this.vaultData = vaultData;
      this.isVaultOpen = true;
      
      // Add to recent vaults
      this.addToRecentVaults({
        name: vaultData.name || 'Unnamed Vault',
        fileName: fileHandle.name,
        lastOpened: new Date().toISOString()
      });
      
      // Save state and update UI
      await this.saveState();
      this.updateUI();
      
      console.log('✅ Vault opened successfully:', fileHandle.name);
      this.showSuccess('Vault opened successfully!');
      
    } catch (error) {
      if (error.name === 'AbortError') {
        console.log('User cancelled file selection');
        return;
      }
      console.error('❌ Failed to open vault:', error);
      this.showError('Failed to open vault: ' + error.message);
    }
  }
  
  async openRecentVault(vault) {
    console.log('🕐 Opening recent vault:', vault.name);
    // For now, just open file picker since we can't persist file handles
    await this.openExistingVault();
  }
  
  async addMemory() {
    console.log('✨ Adding new memory...');
    
    try {
      await this.showAddMemoryModal();
    } catch (error) {
      console.error('❌ Failed to add memory:', error);
      this.showError('Failed to add memory: ' + error.message);
    }
  }
  
  async openWebApp() {
    console.log('🌐 Opening Emma Web App...');
    
    try {
      await chrome.tabs.create({
        url: 'https://emma-vault.onrender.com'
      });
      
      // Close popup
      window.close();
      
    } catch (error) {
      console.error('❌ Failed to open web app:', error);
      this.showError('Failed to open web app');
    }
  }
  
  async downloadVault() {
    console.log('⬇️ Downloading vault...');
    
    if (!this.vaultData) {
      this.showError('No vault open');
      return;
    }
    
    try {
      // Create download blob
      const vaultJson = JSON.stringify(this.vaultData, null, 2);
      const blob = new Blob([vaultJson], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      
      // Trigger download
      const a = document.createElement('a');
      a.href = url;
      a.download = `${this.vaultData.name || 'vault'}-backup.emma`;
      a.click();
      
      URL.revokeObjectURL(url);
      
      console.log('✅ Vault downloaded');
      this.showSuccess('Vault downloaded successfully!');
      
    } catch (error) {
      console.error('❌ Download failed:', error);
      this.showError('Failed to download vault');
    }
  }
  
  async closeVault() {
    console.log('🔒 Closing vault...');
    
    this.currentVault = null;
    this.vaultData = null;
    this.isVaultOpen = false;
    
    await this.saveState();
    this.updateUI();
    
    console.log('✅ Vault closed');
  }
  
  // Modal Functions
  async showVaultCreationModal() {
    const modalContent = `
      <div class="modal-header">
        <h2>🌟 Create New Vault</h2>
        <p>Create a new .emma vault to store your precious memories</p>
      </div>
      
      <form id="createVaultForm" class="modal-form">
        <div class="form-group">
          <label for="vaultName">Vault Name:</label>
          <input type="text" id="vaultName" placeholder="My Memories" required>
        </div>
        
        <div class="form-group">
          <label for="vaultPassword">Password (optional):</label>
          <input type="password" id="vaultPassword" placeholder="Leave empty for no password">
        </div>
        
        <div class="form-actions">
          <button type="button" class="btn-secondary" onclick="emmaApp.closeModal()">Cancel</button>
          <button type="submit" class="btn-primary">Create Vault</button>
        </div>
      </form>
    `;
    
    this.showModal(modalContent);
    
    // Handle form submission
    document.getElementById('createVaultForm').addEventListener('submit', async (e) => {
      e.preventDefault();
      
      const name = document.getElementById('vaultName').value;
      const password = document.getElementById('vaultPassword').value;
      
      await this.performVaultCreation(name, password);
    });
  }
  
  async showAddMemoryModal() {
    const modalContent = `
      <div class="modal-header">
        <h2>✨ Add New Memory</h2>
        <p>Capture a precious moment</p>
      </div>
      
      <form id="addMemoryForm" class="modal-form">
        <div class="form-group">
          <label for="memoryContent">Memory:</label>
          <textarea id="memoryContent" placeholder="Describe your memory..." rows="4" required></textarea>
        </div>
        
        <div class="form-group">
          <label for="memoryEmotion">Emotion:</label>
          <select id="memoryEmotion">
            <option value="happy">Happy 😊</option>
            <option value="peaceful">Peaceful 😌</option>
            <option value="nostalgic">Nostalgic 🥰</option>
            <option value="grateful">Grateful 🙏</option>
            <option value="neutral">Neutral 😐</option>
          </select>
        </div>
        
        <div class="form-group">
          <label for="memoryImportance">Importance (1-10):</label>
          <input type="range" id="memoryImportance" min="1" max="10" value="5">
          <span id="importanceValue">5</span>
        </div>
        
        <div class="form-actions">
          <button type="button" class="btn-secondary" onclick="emmaApp.closeModal()">Cancel</button>
          <button type="submit" class="btn-primary">Save Memory</button>
        </div>
      </form>
    `;
    
    this.showModal(modalContent);
    
    // Update importance display
    const slider = document.getElementById('memoryImportance');
    const display = document.getElementById('importanceValue');
    slider.addEventListener('input', () => {
      display.textContent = slider.value;
    });
    
    // Handle form submission
    document.getElementById('addMemoryForm').addEventListener('submit', async (e) => {
      e.preventDefault();
      
      const content = document.getElementById('memoryContent').value;
      const emotion = document.getElementById('memoryEmotion').value;
      const importance = parseInt(document.getElementById('memoryImportance').value);
      
      await this.performAddMemory(content, emotion, importance);
    });
  }
  
  showModal(content) {
    this.elements.modalContent.innerHTML = content;
    this.elements.modalOverlay.classList.remove('hidden');
  }
  
  closeModal() {
    this.elements.modalOverlay.classList.add('hidden');
  }
  
  // Vault Operations
  async performVaultCreation(name, password) {
    try {
      // Create vault data structure
      const vaultData = {
        version: '1.0',
        name: name,
        created: new Date().toISOString(),
        encryption: {
          enabled: !!password,
          algorithm: password ? 'AES-GCM' : null
        },
        content: {
          memories: {},
          people: {},
          settings: {}
        },
        stats: {
          memoryCount: 0,
          peopleCount: 0,
          totalSize: 0
        }
      };
      
      // Show file save picker
      const fileHandle = await window.showSaveFilePicker({
        types: [
          {
            description: 'Emma Vault Files',
            accept: {
              'application/emma': ['.emma']
            }
          }
        ],
        suggestedName: `${name.toLowerCase().replace(/\s+/g, '-')}.emma`
      });
      
      // Write vault to file
      const writable = await fileHandle.createWritable();
      await writable.write(JSON.stringify(vaultData, null, 2));
      await writable.close();
      
      // Set up vault
      this.currentVault = {
        fileHandle: fileHandle,
        fileName: fileHandle.name,
        lastSync: new Date().toISOString(),
        lastOpened: new Date().toISOString()
      };
      
      this.vaultData = vaultData;
      this.isVaultOpen = true;
      
      // Add to recent vaults
      this.addToRecentVaults({
        name: name,
        fileName: fileHandle.name,
        lastOpened: new Date().toISOString()
      });
      
      // Save state and update UI
      await this.saveState();
      this.updateUI();
      this.closeModal();
      
      console.log('✅ Vault created successfully:', fileHandle.name);
      this.showSuccess('Vault created successfully!');
      
    } catch (error) {
      if (error.name === 'AbortError') {
        return;
      }
      throw error;
    }
  }
  
  async performAddMemory(content, emotion, importance) {
    if (!this.isVaultOpen) {
      throw new Error('No vault open');
    }
    
    try {
      // Create memory object
      const memoryId = this.generateId('memory');
      const memory = {
        id: memoryId,
        created: new Date().toISOString(),
        updated: new Date().toISOString(),
        content: content,
        metadata: {
          emotion: emotion,
          importance: importance,
          tags: [],
          people: []
        }
      };
      
      // Add to vault data
      this.vaultData.content.memories[memoryId] = memory;
      this.vaultData.stats.memoryCount = Object.keys(this.vaultData.content.memories).length;
      
      // Save to file
      await this.saveVaultToFile();
      
      // Update UI and close modal
      this.updateUI();
      this.closeModal();
      
      console.log('✅ Memory added successfully:', memoryId);
      this.showSuccess('Memory saved successfully!');
      
    } catch (error) {
      throw error;
    }
  }
  
  async saveVaultToFile() {
    if (!this.currentVault?.fileHandle || !this.vaultData) {
      throw new Error('No vault or file handle available');
    }
    
    try {
      const writable = await this.currentVault.fileHandle.createWritable();
      await writable.write(JSON.stringify(this.vaultData, null, 2));
      await writable.close();
      
      // Update sync time
      this.currentVault.lastSync = new Date().toISOString();
      await this.saveState();
      
      console.log('💾 Vault saved to file');
      
    } catch (error) {
      console.error('❌ Failed to save vault to file:', error);
      throw error;
    }
  }
  
  // Utility Functions
  validateVaultData(data) {
    return data && 
           data.version && 
           data.content && 
           typeof data.content.memories === 'object';
  }
  
  addToRecentVaults(vault) {
    // Remove existing entry
    this.recentVaults = this.recentVaults.filter(v => v.fileName !== vault.fileName);
    
    // Add to beginning
    this.recentVaults.unshift(vault);
    
    // Keep only last 5
    this.recentVaults = this.recentVaults.slice(0, 5);
  }
  
  generateId(prefix) {
    return `${prefix}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }
  
  calculateVaultSize() {
    if (!this.vaultData) return 0;
    return JSON.stringify(this.vaultData).length;
  }
  
  formatBytes(bytes) {
    if (!bytes || bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  }
  
  formatTimeAgo(date) {
    const now = new Date();
    const diff = now - date;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);
    
    if (minutes < 1) return 'Just now';
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    return `${days}d ago`;
  }
  
  showSuccess(message) {
    // Simple success notification
    console.log('✅', message);
    // TODO: Add toast notification
  }
  
  showError(message) {
    // Simple error notification
    console.error('❌', message);
    alert(message); // Temporary - replace with toast
  }
}

// Initialize the application
let emmaApp;

document.addEventListener('DOMContentLoaded', async () => {
  console.log('💜 Emma Vault Extension starting...');
  
  emmaApp = new EmmaVaultExtension();
  await emmaApp.init();
  
  // Make available globally for modal callbacks
  window.emmaApp = emmaApp;
  
  console.log('🎉 Emma Vault Extension ready for Debbe and all precious memories!');
});
